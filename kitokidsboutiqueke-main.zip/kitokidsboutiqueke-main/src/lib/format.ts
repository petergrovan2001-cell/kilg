export function formatKES(amount: number) {
  return `KSh ${amount.toLocaleString('en-KE')}`
}
